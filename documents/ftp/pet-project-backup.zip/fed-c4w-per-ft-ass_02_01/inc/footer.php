<footer class="flex wrap">
    <section>
    <span class="copyright-info">
            &copy; 
            <span id="copyright">
                <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script>
            </span>
        <a href="https://github.com/ozmos" target="blank">
					Osamu Morozumi</a>
        </span>
    </section>
    <section>
            <a href="https://pcwebsites.com.au" target="blank">Perth Custom Websites</a>
    </section>
    <section>
      <ul class="nav-list flex wrap">
        <li class="nav-item">
          <a href="/index.php#home">Home</a>
        </li>
        <li class="nav-item">
          <a href="/index.php#about">About</a>
        </li><li class="nav-item">
          <a href="/articles.php">Articles</a>
        </li><li class="nav-item">
          <a href="/contact.php">Contact</a>
        </li>
      </ul>
    </section>
  </footer>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/6.26.0/babel.min.js"></script>
  <script src="js/nav.js"></script>
</body>
</html>