

  <!-- header -->
<header class="flex">
  <div class="headings">
    <h1>Zen Journal</h1>
    <h2 class="subheading">Practical instructions and personal reflections</h2>
  </div> 

</header>
<!-- navigation -->
<nav class="flex">
  <ul class="nav-list wrap" id="nav">
    <li class="nav-item">
      <a class="hover-green-dark" href="/index.php#home">Home</a>
    </li>
    <li class="nav-item">
      <a class="hover-green-dark" href="/index.php#about">About</a>
    </li><li class="nav-item">
      <a class="hover-green-dark" href="/articles.php">Articles</a>
    </li><li class="nav-item">
      <a class="hover-green-dark" href="/contact.php">Contact</a>
    </li>
  </ul>
  <div id="menu-toggle" onclick="classToggle('nav', 'toggle-reveal')">
    <div class="hamburger top">
    </div>
    <div class="hamburger top">
    </div>
    <div class="hamburger">
    </div>
  </div>
</nav>
 
