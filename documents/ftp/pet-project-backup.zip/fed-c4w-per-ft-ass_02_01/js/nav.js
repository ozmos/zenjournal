//reusable class toggle function:
function classToggle(id, className) {
    return document.getElementById(id).classList.toggle(className);
}

//collapse dropdown if user clicks outside box
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
      const dropdowns = document.getElementsByClassName("dropdown-content");
      for (let e of dropdowns) {
        if (e.classList.contains('toggle-reveal')) {
          e.classList.remove('toggle-reveal');
       
        }
      }
      
    }
  } 